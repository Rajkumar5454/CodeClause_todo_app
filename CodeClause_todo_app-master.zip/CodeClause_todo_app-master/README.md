# MytodoList
A new Flutter project.

# Output
![Github Todo](https://user-images.githubusercontent.com/87336351/233617314-391bccb8-2ed3-4897-9501-c1983e3ef046.jpg)

![Github Todo(1)](https://user-images.githubusercontent.com/87336351/233617673-cffcaacd-1679-49e9-b28d-9a107bdc8ebc.jpg)


https://user-images.githubusercontent.com/87336351/233617728-c53ff5c8-64a9-410d-b4d0-113aea671f80.mp4



## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://flutter.dev/docs/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://flutter.dev/docs/cookbook)

For help getting started with Flutter, view our
[online documentation](https://flutter.dev/docs), which offers tutorials,
samples, guidance on mobile development, and a full API reference.
